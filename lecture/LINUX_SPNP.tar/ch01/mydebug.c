#include <stdio.h>

int main(void)
{
	int num;

	printf("num? ");
	scanf("%d", &num);
	printf("Your input number is %d\n", num);
	return 0;
}
