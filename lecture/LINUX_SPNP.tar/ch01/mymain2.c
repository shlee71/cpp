#include <stdio.h>

int main(void)
{
	printf("main() called\n");
	myshared(10);
	printf("main() end\n");
	return 0;
}
