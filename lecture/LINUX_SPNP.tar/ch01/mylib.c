#include <stdio.h>
#include <time.h>
#include <sys/types.h>

int main(void)
{
	time_t cur_time;
	char *time_str;

	time(&cur_time);
	time_str=ctime(&cur_time);
	printf("Current Time = %s\n", time_str);

	return 0;
}
