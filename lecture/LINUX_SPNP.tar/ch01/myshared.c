#include <stdio.h>

void myshared(int num)
{
	printf("This is shared library function : %d\n", num);
}
