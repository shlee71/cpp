#include <sys/times.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i;
	time_t c_time;

	clock_t oldtime, newtime;
	struct tms oldtms, newtms;

	if ((oldtime=times(&oldtms)) == -1)
	{	perror("old times");
		exit(1);
	}

	for (i=1; i<=100000; i++)
		time(&c_time);
	
	if ((newtime=times(&newtms)) == -1)
	{	perror("new times");
		exit(1);
	}

	printf("Real Time : %d clocks\n", newtime-oldtime);
	printf("User mode Time : %d clocks\n", newtms.tms_utime-oldtms.tms_utime);
	printf("System mode Time : %d clocks\n", newtms.tms_stime-oldtms.tms_stime);
	return 0;
}	
